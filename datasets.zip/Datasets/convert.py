import csv

f = open('metro.nt', 'w')

first = True
with open('metro.csv', newline='') as csvfile:
    spamreader = csv.reader(csvfile, delimiter=',')
    for row in spamreader:
        if first:
            first = False
        else:
            if ('statement' not in row[0] and 
                'statement' not in row[1] and
                'statement' not in row[2]):
                f.write('<{}> <{}> <{}> . \n'.format(row[0], row[1], row[2]))


f.close()