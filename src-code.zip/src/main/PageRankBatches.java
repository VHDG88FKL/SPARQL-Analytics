package main;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

import org.apache.jena.atlas.lib.SetUtils;
import org.apache.jena.query.QueryExecution;
import org.apache.jena.query.QueryExecutionFactory;
import org.apache.jena.query.QuerySolution;
import org.apache.jena.query.ResultSet;
import org.apache.jena.query.ResultSetFactory;
import org.apache.jena.query.ResultSetFormatter;
import org.apache.jena.rdf.model.Model;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.sparql.resultset.ResultSetApply;
import org.apache.jena.sparql.resultset.ResultSetCompare;
import org.apache.jena.sparql.util.ResultSetUtils;

public class PageRankBatches {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int NUMBER_OF_ITERATIONS = 10;

		Model dataModel = ModelFactory.createDefaultModel();
		dataModel.read(args[0]);

		long start = System.currentTimeMillis();

		String query_nodes = "SELECT DISTINCT ?node WHERE { { ?node ?p ?o } UNION { ?s ?p ?node } }";

		QueryExecution qe = QueryExecutionFactory.create(query_nodes, dataModel);

		ResultSet rs = qe.execSelect();

		ArrayList<String> nodes = new ArrayList<>();
		
		HashMap<String, Integer> degrees = new HashMap<>();
		
		int count_nodes = 0;
		while (rs.hasNext()) {
			QuerySolution qs = rs.next();
			String node = "<" + qs.get("node").toString() + ">";
			nodes.add(node);
			count_nodes++;
		}

		System.out.println("Terminó de armar nodes");

		String values_count = "VALUES (?n) { (" + count_nodes + ") }";

		qe.close();

		HashMap<String, Float> pr = new HashMap<>();

		for (String node : nodes) {	
			pr.put(node, (float)1/count_nodes);
		}

		for (int i = 0; i < NUMBER_OF_ITERATIONS; i++) {

			System.out.println("Iteración: " + i);

			HashMap<String, Float> pr_next = new HashMap<>();

			System.out.println("PAGERANK NEXT");
			for (String node : nodes) {

				// System.out.println("Node: " + node);

				String query_node_neighbours = "SELECT DISTINCT ?node WHERE {"
						+ "{ VALUES (?node) { ( " + node + " ) } } UNION "
						+ "{ SELECT ?node WHERE { ?node ?p " + node + " } }"
						+ "}";

				ArrayList<String> nodes_neighbours = query_to_list(query_node_neighbours, dataModel);
				String values_node_neighbours = Utilities.queryStringAsValues(query_node_neighbours, dataModel);


				String query_degrees = "SELECT ?node (COUNT(DISTINCT ?o) as ?degree) "
						+ "WHERE { { " + values_node_neighbours + " } . "
						+ " OPTIONAL { ?node ?p ?o } } GROUP BY ?node";

				String values_degrees = Utilities.queryStringAsValues(query_degrees, dataModel);


				String query_rank_next = "SELECT ?neighbour (SUM(?rankEach) AS ?rankNext) WHERE { "
						+ "{ " + values_degrees + " } . "
						+ "{ " + pr_to_values(pr, nodes_neighbours, "?rank") + " } . "
						+ "?node ?p ?neighbour . BIND((?rank*0.85)/?degree AS ?rankEach) } GROUP BY ?neighbour";


				// System.out.println(query_rank_next);

				try {
					HashMap<String, Float> pr_node = calculate_rank_next(query_rank_next, dataModel, "rankNext", node);
					pr_next.putAll(pr_node);
				} catch (Exception e) {
					System.out.println("Se cayó en el nodo: " + node);
					System.out.println("La query era: " + query_rank_next);
					throw e;
				}
			}

			float pr_sum = 0;
			for (float value : pr_next.values()) {
				pr_sum += value;
			}

			pr_sum = (1 - pr_sum)/count_nodes;

			String values_pr_sum = "VALUES (?weak) { (" + pr_sum + ") }";

			pr.clear();

			System.out.println("PAGERANK UPDATE");
			for (String node : nodes) {

				// System.out.println("Node: " + node);

				ArrayList<String> node_wrapper = new ArrayList<>();
				node_wrapper.add(node);

				String query_pr = "SELECT ?node (?rankBound+?weak AS ?rank) WHERE { "
						+ "{ VALUES (?node) { ( " + node + " ) } } . "
						+ "OPTIONAL { " + pr_to_values(pr_next, node_wrapper, "?rankNext") + " } . "
						+ "{ " + values_pr_sum + " } . "
						+ "BIND(COALESCE(?rankNext, 0) AS ?rankBound) }";


				// System.out.println(query_pr);

				try {
					HashMap<String, Float> pr_node = calculate_rank_next(query_pr, dataModel, "rank", node);
					pr.putAll(pr_node);
				} catch (Exception e) {
					System.out.println("Se cayó en el nodo: " + node);
					System.out.println("La query era: " + query_pr);
					throw e;
				}



			}

		}

		if (Utilities.PRINT_VALUES) {
			System.out.println(pr);
		}

		long total = System.currentTimeMillis() - start;

		System.out.println("END - Time: " + total);

	}

	public static HashMap<String, Float> calculate_rank_next(String queryString, Model dataModel, String rankName) {
		QueryExecution qe = QueryExecutionFactory.create(queryString, dataModel);
		ResultSet rs = qe.execSelect();
		HashMap<String, Float> result = new HashMap<>();
		while (rs.hasNext()) {
			QuerySolution qs = rs.next();
			if (qs.contains("node")) {
				result.put("<" + qs.get("node").toString() + ">", qs.get(rankName).asLiteral().getFloat());
			} else {
				result.put("<" + qs.get("neighbour").toString() + ">", qs.get(rankName).asLiteral().getFloat());
			}
		}
		return result;
	}

	public static HashMap<String, Float> calculate_rank_next(String queryString, Model dataModel, String rankName, String node) {
		QueryExecution qe = QueryExecutionFactory.create(queryString, dataModel);
		ResultSet rs = qe.execSelect();
		HashMap<String, Float> result = new HashMap<>();
		while (rs.hasNext()) {
			QuerySolution qs = rs.next();
			if (qs.contains("node")) {
				if (("<" + qs.get("node") + ">").equals(node)) {
					result.put("<" + qs.get("node").toString() + ">", qs.get(rankName).asLiteral().getFloat());
				}
			} else {
				if (("<" + qs.get("neighbour") + ">").equals(node)) {
					result.put("<" + qs.get("neighbour").toString() + ">", qs.get(rankName).asLiteral().getFloat());
				}
			}
		}
		return result;
	}

	public static ArrayList<String> query_to_list(String queryString, Model dataModel) {
		ArrayList<String> result = new ArrayList<>();
		QueryExecution qe = QueryExecutionFactory.create(queryString, dataModel);
		ResultSet rs = qe.execSelect();

		while(rs.hasNext()) {
			QuerySolution qs = rs.next();
			result.add("<" + qs.get("node").toString() + ">");
		}

		return result;
	}

	public static String pr_to_values(HashMap<String, Float> rs, ArrayList<String> nodes, String rankName) {
		String values_string = "VALUES (?node " + rankName + ") { ";

		for (String node : nodes) {
			if (rs.containsKey(node)) {
				values_string += ("( " + node + " " + rs.get(node) + " ) " );
			} else {
				values_string += ("( " + node + " 0 ) " );
			}
			
		}

		values_string += "}";

		return values_string;
	}

}
