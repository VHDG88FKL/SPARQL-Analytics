package main;

import java.util.List;

import org.apache.jena.rdf.model.Model;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.tdb.TDBLoader;

public class BFS {

	public static void main(String[] args) {
		
		Model dataModel = ModelFactory.createDefaultModel();
		dataModel.read(args[0]);
		
		AssignStatement depth = new AssignStatement(
				"depth", 
				"SELECT * WHERE { VALUES (?depth ?node) { (0 <http://example.org/v6009541>) } }"
				);
		
		AssignStatement iter = new AssignStatement(
				"iter", 
				"SELECT * WHERE { VALUES (?depth) { (0) } }"
				);
		
		AssignStatement depthNext = new AssignStatement(
				"depthNext", 
				"SELECT DISTINCT (?neighbour as ?node2) (?depth + 1 as ?depth2) "
				+ "WHERE { ?node ?p ?neighbour . { SELECT * WHERE { QVALUES(depth) } } . { SELECT * WHERE { QVALUES(iter) } } }"
				);
		
		AssignStatement depthNextNew = new AssignStatement(
				"depthNextNew", 
				"SELECT * WHERE { { SELECT (?node2 as ?node) (?depth2 as ?depth) WHERE { QVALUES(depthNext) } } MINUS { { SELECT ?node WHERE{ QVALUES(depth) } } } }"
				);
		
		AssignStatement depth2 = new AssignStatement(
				"depth", 
				"SELECT * WHERE { { SELECT * WHERE { QVALUES(depthNextNew) } } UNION { SELECT * WHERE { QVALUES(depth) } } }"
				);
		
		AssignStatement iter2 = new AssignStatement(
				"iter", 
				"SELECT (?depth2 + 1 AS ?depth) WHERE { { SELECT (?depth AS ?depth2) WHERE { QVALUES(iter) } } }"
				);
		

		
		
		
		
		Procedure p = new Procedure(dataModel);
		Procedure p2 = new Procedure(dataModel, p.context);
		
		
		
		p.statements.add(depth);
		p.statements.add(iter);
		p2.statements.add(depthNext);
		p2.statements.add(depthNextNew);
		p2.statements.add(depth2);
		p2.statements.add(iter2);
		
		String askString = "ASK { SELECT * WHERE { QVALUES(depthNextNew) } } ";
		
		LoopStatement lst = new LoopStatement(askString, p2);
		
		OutputStatement out = new OutputStatement("depth");
		
		p.statements.add(lst);
		p.statements.add(out);
		
		long start = System.currentTimeMillis();

		p.execProcedure();
		
		long total = System.currentTimeMillis() - start;
		
		System.out.println("END - Time: " + total);
		

				
	}

}
