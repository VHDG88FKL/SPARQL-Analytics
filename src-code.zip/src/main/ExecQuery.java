package main;

import java.util.List;

import org.apache.jena.datatypes.RDFDatatype;
import org.apache.jena.query.Dataset;
import org.apache.jena.query.Query;
import org.apache.jena.query.QueryExecution;
import org.apache.jena.query.QueryExecutionFactory;
import org.apache.jena.query.QueryFactory;
import org.apache.jena.query.QuerySolution;
import org.apache.jena.query.ResultSet;
import org.apache.jena.query.ResultSetFormatter;
import org.apache.jena.rdf.model.Literal;
import org.apache.jena.rdf.model.Model;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.rdf.model.RDFNode;
import org.apache.jena.riot.resultset.rw.ResultSetReaderJSON;
import org.apache.jena.riot.resultset.rw.ResultSetWriterJSON;
import org.apache.jena.sparql.util.ResultSetUtils;
import org.apache.jena.tdb.TDBFactory;

public class ExecQuery {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String queryString = "SELECT * " + 
				"WHERE " + 
				"{ " + 
				"  ?node <http://www.wikidata.org/prop/direct/P31> <http://www.wikidata.org/entity/Q13442814> ; <http://www.wikidata.org/prop/direct/P921> <http://www.wikidata.org/entity/Q202864> ; <http://www.wikidata.org/prop/direct/P2860> ?cite . " + 
				"  ?cite <http://www.wikidata.org/prop/direct/P31> <http://www.wikidata.org/entity/Q13442814> ; <http://www.wikidata.org/prop/direct/P921> <http://www.wikidata.org/entity/Q202864> . " +
				"}";
		
		// Parse
		Query query = QueryFactory.create(queryString);
		
		String tdbFolder = "/Users/adriansotosuarez/Documents/Research/SPARQL-Analytics/ExamplesPaper/zika-authors";
		Dataset dataset = TDBFactory.createDataset(tdbFolder);
		Model tdb = dataset.getDefaultModel();
		
		QueryExecution qe = QueryExecutionFactory.create(query, tdb);
		
		ResultSet rs = qe.execSelect();
				
		System.out.println(ResultSetFormatter.asText(rs));

		qe.close();
		tdb.close();
				

	}

}
