package main;

import java.util.List;

import org.apache.jena.tdb.TDBLoader;

public class WCC_Old {

	public static void main(String[] args) {
		
		AssignStatement wcc = new AssignStatement(
				"wcc", 
				"SELECT DISTINCT ?node (?node AS ?wcc) (?node AS ?wccPrev) WHERE { { ?x ?p ?node } UNION { ?node ?p ?x } }"
				);
		
		AssignStatement wcc2 = new AssignStatement(
				"wcc", 
				"SELECT DISTINCT ?node (?wccNew AS ?wcc) (?wccNode AS ?wccPrev) WHERE {"
				+ " {{ ?node ?p ?neighbour } UNION { ?neighbour ?p ?node }} . "
				+ "{ SELECT ?node (?wcc AS ?wccNode) WHERE { QVALUES(wcc) } } . "
				+ "{ SELECT (?node AS ?neighbour) (?wcc AS ?wccNeighbour) WHERE { QVALUES(wcc) } } . "
				+ "BIND(IF(str(?wccNode)<=str(?wccNeighbour), ?wccNode, ?wccNeighbour) AS ?wccNew ) }"
				);
		

		
		
		
		
		Procedure p = new Procedure("/Users/adriansotosuarez/Documents/Research/SPARQL-Analytics/WCC/wcc-example");
		Procedure p2 = new Procedure("/Users/adriansotosuarez/Documents/Research/SPARQL-Analytics/WCC/wcc-example", p.context);
		
		
		
		p.statements.add(wcc);
		OutputStatement first_out = new OutputStatement("wcc");
		p.statements.add(first_out);

		p2.statements.add(wcc2);
		
		String askString = "ASK { SELECT * WHERE { QVALUES(wcc) . FILTER(?wcc != ?wccPrev) } } ";
		
		LoopStatement lst = new LoopStatement(askString, p2);
		
		OutputStatement out = new OutputStatement("wcc");
		
		p.statements.add(lst);
		p2.statements.add(out);
		
		p.execProcedure();
		

				
	}

}
