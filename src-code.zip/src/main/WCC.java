package main;

import java.util.List;

import org.apache.jena.rdf.model.Model;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.tdb.TDBLoader;

public class WCC {

	public static void main(String[] args) {
		
		Model dataModel = ModelFactory.createDefaultModel();
		dataModel.read(Utilities.path_data);
		
		// String tdbPath = args[0];
		
		AssignStatement wcc = new AssignStatement(
				"wcc", 
				"SELECT ?node (?node AS ?wcc) WHERE { { ?x ?p ?node } UNION { ?node ?p ?x } }"
				);
		
		AssignStatement wcc_prev = new AssignStatement(
				"wcc_prev", 
				"SELECT ?node (?wcc AS ?wccPrev) WHERE { QVALUES(wcc) }"
				);
		
		AssignStatement wcc2 = new AssignStatement(
				"wcc", 
				"SELECT ?node (MIN(?wccNew) AS ?wcc) WHERE {"
				+ " {{ ?node ?p ?neighbour } UNION { ?neighbour ?p ?node }} . "
				+ "{ SELECT ?node (?wcc AS ?wccNode) WHERE { QVALUES(wcc) } } . "
				+ "{ SELECT (?node AS ?neighbour) (?wcc AS ?wccNeighbour) WHERE { QVALUES(wcc) } } . "
				+ "BIND(IF(str(?wccNode)<=str(?wccNeighbour), ?wccNode, ?wccNeighbour) AS ?wccNew ) } GROUP BY ?node"
				);
		
		
		
		Procedure p = new Procedure(dataModel);
		Procedure p2 = new Procedure(dataModel, p.context);
		
		
		
		p.statements.add(wcc);
		
		p2.statements.add(wcc_prev);
		p2.statements.add(wcc2);
		
		String askString = "ASK { SELECT * WHERE { QVALUES(wcc) . QVALUES(wcc_prev) . FILTER(?wcc != ?wccPrev) } } ";
		
		LoopStatement lst = new LoopStatement(askString, p2);
		
		OutputStatement out = new OutputStatement("wcc");
		
		p.statements.add(lst);
		p.statements.add(out);
		
		long start = System.currentTimeMillis();

		p.execProcedure();
		
		long total = System.currentTimeMillis() - start;
		
		System.out.println("END - Time: " + total);
		

				
	}

}
