package main;

import java.util.List;

import org.apache.jena.rdf.model.Model;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.tdb.TDBLoader;

public class PageRank {

	public static void main(String[] args) {

		Model dataModel = ModelFactory.createDefaultModel();
		dataModel.read(Utilities.path_data);

		// String tdb_folder = "/Users/adriansotosuarez/Documents/Research/SPARQL-Analytics/ExamplesPaper/zika-authors";

		AssignStatement nodes = new AssignStatement(
				"nodes", 
				"SELECT DISTINCT ?node WHERE { { SELECT ?node WHERE { ?node ?y ?z } } UNION { SELECT ?node WHERE { ?x ?y ?node }} }");

		AssignStatement n = new AssignStatement(
				"n", 
				"SELECT (COUNT(*) AS ?n) WHERE { QVALUES(nodes) }"
				);

		AssignStatement degree = new AssignStatement(
				"degree", 
				"SELECT ?node (COUNT(DISTINCT ?o) as ?degree) "
						+ "WHERE { { SELECT * WHERE { QVALUES(nodes) } } . "
						+ "OPTIONAL { ?node ?p ?o } } GROUP BY ?node"
				);

		AssignStatement rank = new AssignStatement(
				"rank", 
				"SELECT ?node (1.0/?n AS ?rank) WHERE "
						+ "{ { SELECT * WHERE { QVALUES(nodes) } } ."
						+ " { SELECT * WHERE { QVALUES(n) } } }"
				);

		AssignStatement rankNext = new AssignStatement(
				"rankNext", 
				"SELECT ?neighbour (SUM(?rankEach) AS ?rankNext) WHERE { "
						+ "{ SELECT * WHERE { QVALUES(degree) } } . "
						+ "{ SELECT * WHERE { QVALUES(rank) } } . "
						+ "?node ?p ?neighbour . BIND((?rank*0.85)/?degree AS ?rankEach) } GROUP BY ?neighbour"
				);

		AssignStatement weakRank = new AssignStatement(
				"weakRank", 
				"SELECT ((1-SUM(?rankNext))/?n AS ?weak) WHERE { "
						+ "{ SELECT * WHERE { QVALUES(rankNext) } } . "
						+ "{ SELECT * WHERE { QVALUES(n) } } } GROUP BY ?n");

		AssignStatement rank2 = new AssignStatement(
				"rank", 
				"SELECT ?node (?rankBound+?weak AS ?rank) WHERE { "
						+ "{ SELECT * WHERE { QVALUES(nodes) } } . "
						+ "OPTIONAL { { SELECT (?neighbour AS ?node) ?rankNext WHERE { QVALUES(rankNext) } } } . "
						+ "{ SELECT * WHERE { QVALUES(weakRank) } } . "
						+ "BIND(COALESCE(?rankNext, 0) AS ?rankBound) }"
				);
		

		// Procedure p = new Procedure(args[0]);
		// Procedure p2 = new Procedure(args[0], p.context);

		Procedure p = new Procedure(dataModel);
		Procedure p2 = new Procedure(dataModel, p.context);

		LoopStatement lst = new LoopStatement(10, p2);


		OutputStatement out = new OutputStatement("rank");

		p.statements.add(nodes);
		p.statements.add(n);
		p.statements.add(degree);
		p.statements.add(rank);

		p2.statements.add(rankNext);
		p2.statements.add(weakRank);
		p2.statements.add(rank2);

		p.statements.add(lst);
		p.statements.add(out);


		long start = System.currentTimeMillis();

		p.execProcedure();

		long total = System.currentTimeMillis() - start;

		System.out.println("END - Time: " + total);

		// dataModel.close();



	}

}
