package main;

public interface Statement {
	
	public void execute(Context context);
	
	public String getType();

}
