package main;

import java.util.List;

import org.apache.jena.rdf.model.Model;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.tdb.TDBLoader;

public class Dijkstra {

	public static void main(String[] args) {
		
		Model dataModel = ModelFactory.createDefaultModel();
		dataModel.read(Utilities.path_data);
		
		AssignStatement visited = new AssignStatement(
				"visited", 
				"SELECT * WHERE { VALUES (?path ?node ?depth) { ( \"\" <http://example.org/v6009541> 0 ) } }"
				);
		
		AssignStatement iter = new AssignStatement(
				"iter", 
				"SELECT * WHERE { VALUES (?depth) { (0) } }"
				);
		
		AssignStatement visit = new AssignStatement(
				"visit", 
				"SELECT DISTINCT (CONCAT(?path2,\" -[\",STR(?p),\"]-> \",STR(?neighbour)) AS ?path) (?neighbour as ?node) (?depth2 + 1 AS ?depth) "
				+ "WHERE { ?node2 ?p ?neighbour . FILTER(!isLiteral(?neighbour)) . { SELECT (?path AS ?path2) (?node AS ?node2) ?depth2 WHERE { QVALUES(visited) } } . { { SELECT (?depth AS ?depth2) WHERE { QVALUES(iter) } } }  }");
		
		AssignStatement visitNew = new AssignStatement(
				"visitNew", 
				"SELECT * WHERE { { SELECT * WHERE { QVALUES(visit) } } MINUS { { SELECT ?node WHERE { QVALUES(visited) } } } }"
				);
		
		AssignStatement visited2 = new AssignStatement(
				"visited", 
				"SELECT * WHERE { { SELECT * WHERE { QVALUES(visitNew) } } UNION { SELECT * WHERE { QVALUES(visited) } } }"
				);
		
		AssignStatement iter2 = new AssignStatement(
				"iter", 
				"SELECT (?depth2 + 1 AS ?depth) WHERE { { SELECT (?depth AS ?depth2) WHERE { QVALUES(iter) } } }"
				);
		
		AssignStatement shortestPaths = new AssignStatement(
				"shortestPaths", 
				"SELECT * WHERE { QVALUES(visited) . VALUES (?node) { (<http://example.org/v1124>) } }"
				);
		
		
		

		
		
		
		
		Procedure p = new Procedure(dataModel);
		Procedure p2 = new Procedure(dataModel, p.context);
		
		
		OutputStatement out = new OutputStatement("shortestPaths");
		
		p.statements.add(visited);
		p.statements.add(iter);
		p2.statements.add(visit);
		p2.statements.add(visitNew);
		p2.statements.add(visited2);
		p2.statements.add(iter2);
		p2.statements.add(shortestPaths);
		
		String askString = "ASK { SELECT * WHERE { QVALUES(visitNew) . FILTER NOT EXISTS { SELECT * WHERE { QVALUES(shortestPaths) } } } }";
		
		LoopStatement lst = new LoopStatement(askString, p2);
				
		p.statements.add(lst);
		p.statements.add(out);
		
		long start = System.currentTimeMillis();

		p.execProcedure();
		
		long total = System.currentTimeMillis() - start;
		
		System.out.println("END - Time: " + total);
		

				
	}

}
