package main;

public class UpdateStatement implements Statement {

	public String queryString;
	
	public UpdateStatement(String queryString) {
	
		this.queryString = queryString;

	}
	
	@Override
	public void execute(Context context) {
		
		// context.execUpdate(this.queryString);
		
	}

	@Override
	public String getType() {
		
		return "update";
	
	}

	
	
}
