package main;

import java.util.List;

public class Parser {

	
	public static List<Statement> parseProcedure(String procedureString) {
		return null;
	}
	
}
