package main;

import java.util.List;

import org.apache.jena.datatypes.RDFDatatype;
import org.apache.jena.query.Dataset;
import org.apache.jena.query.Query;
import org.apache.jena.query.QueryExecution;
import org.apache.jena.query.QueryExecutionFactory;
import org.apache.jena.query.QueryFactory;
import org.apache.jena.query.QuerySolution;
import org.apache.jena.query.ResultSet;
import org.apache.jena.query.ResultSetFormatter;
import org.apache.jena.rdf.model.Literal;
import org.apache.jena.rdf.model.Model;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.rdf.model.RDFNode;
import org.apache.jena.riot.resultset.rw.ResultSetReaderJSON;
import org.apache.jena.sparql.util.ResultSetUtils;
import org.apache.jena.tdb.TDBFactory;
import org.apache.jena.update.UpdateAction;

public class UpdateExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String queryString = "INSERT {"
				+ "<http://ex.org/s> <http://ex.org/p> ?z "
				+ "} WHERE {"
				+ "?x ?y ?z }";

		
		String tdbPath = "/Users/adriansotosuarez/Documents/RDF-Datasets/Example";
		Dataset dataset = TDBFactory.createDataset(tdbPath);
		Model tdb = dataset.getDefaultModel();
		
		UpdateAction.parseExecute(queryString, tdb);
		
		tdb.close();
	
	}

}
