package main;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.jena.datatypes.RDFDatatype;
import org.apache.jena.query.Dataset;
import org.apache.jena.query.QueryExecution;
import org.apache.jena.query.QueryExecutionFactory;
import org.apache.jena.query.QuerySolution;
import org.apache.jena.query.ResultSet;
import org.apache.jena.rdf.model.Literal;
import org.apache.jena.rdf.model.Model;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.rdf.model.RDFNode;
import org.apache.jena.tdb.TDBFactory;

public class Utilities {

	public static String STRING_TO_FIND = "QVALUES";
	public static final boolean PRINT_VALUES = true;
	public static final boolean LOGS = true;


	public static List<int[]> quoteRangeList(String queryString) {

		List<int[]> rangeList = new ArrayList<int[]>();
		boolean finding = false;
		int indexStart = -1;

		for (int i = 0; i < queryString.length(); i++) {

			if (queryString.charAt(i) == '"' && !finding) {
				finding = true;
				indexStart = i;
			} else if (queryString.charAt(i) == '"' && 
					!isEscaped(queryString, i - 1) &&
					finding) {

				int[] newRange = {indexStart, i};
				rangeList.add(newRange);
				finding = false;
			}

		}
		return rangeList;

	}

	public static boolean isEscaped(String queryString, int index) {

		if(queryString.charAt(index) == '\\') {
			int count = 0;
			int numberOfEscapes = 0;
			while(true) {
				if (queryString.charAt(index - count) == '\\') {
					numberOfEscapes++;
				} else {

					break;
				}
				count++;
			}
			return (numberOfEscapes % 2) == 1;
		} else {
			return false;
		}

	}

	public static List<Integer> valuesLocation(String queryString) {



		List<Integer> locations = new ArrayList<Integer>();
		List<int[]> quotedQValues = quoteRangeList(queryString);

		for (int i = 0; i < queryString.length() - STRING_TO_FIND.length(); i++) {
			if (queryString.substring(i, i + STRING_TO_FIND.length()).equals(STRING_TO_FIND)) {
				locations.add(i + STRING_TO_FIND.length());
			}
		}

		List<Integer> notQuotedLocations = new ArrayList<Integer>();
		for (int location : locations) {
			boolean quoted = false;
			for(int[] quotes : quotedQValues) {
				if (quotes[0] <= location && location <= quotes[1]) {
					quoted = true;
					break;
				}
			}
			if (!quoted) {
				notQuotedLocations.add(location);
			}
		}

		return notQuotedLocations;

	}

	public static List<int[]> splitLocation(String queryString) {

		List<int[]> splitLocations = new ArrayList<int[]>();
		List<int[]> quotedQValues = quoteRangeList(queryString);
		List<Integer> locations = new ArrayList<Integer>();

		for (int i = 0; i < queryString.length() - STRING_TO_FIND.length(); i++) {
			if (queryString.substring(i, i + STRING_TO_FIND.length()).equals(STRING_TO_FIND)) {
				locations.add(i + STRING_TO_FIND.length());
			}
		}

		for (int location : locations) {
			boolean quoted = false;
			for(int[] quotes : quotedQValues) {
				if (quotes[0] <= location && location <= quotes[1]) {
					quoted = true;
					break;
				}
			}
			if (!quoted) {

				int endPosition = -1;
				for (int i = location + 1; i < queryString.length(); i++) {
					if (queryString.charAt(i) == ')') {
						endPosition = i;
						break;
					}
				}

				int[] splitLoc = {location - STRING_TO_FIND.length(), endPosition + 1};

				splitLocations.add(splitLoc);
			}
		}

		return splitLocations;
	}

	public static List<String> varNamesValues(String queryString) {

		List<String> varNames = new ArrayList<String>();

		List<Integer> valuesLocations = valuesLocation(queryString);
		for (int location : valuesLocations) {

			int endPosition = -1;
			for (int i = location + 1; i < queryString.length(); i++) {
				if (queryString.charAt(i) == ')') {
					endPosition = i;
					break;
				}
			}
			String varName = queryString.substring(location + 1, endPosition);
			varName = varName.trim();
			varNames.add(varName);

		}

		return varNames;

	}

	public static String queryStringAsValues(String queryString, String dataPath) {
		StringBuilder sb = new StringBuilder();
		sb.append("VALUES (");


		Dataset dataset = TDBFactory.createDataset(dataPath);
		Model dataModel = dataset.getDefaultModel();


		QueryExecution qe = QueryExecutionFactory.create(queryString, dataModel);
		ResultSet rs = qe.execSelect();

		List<String> vars = rs.getResultVars();
		for (String var : vars) {
			sb.append("?" + var + " ");
		}

		sb.append(") { ");

		while (rs.hasNext()) {
			QuerySolution qs = rs.next();
			sb.append("( ");

			for (String var: vars) {
				if (!qs.contains(var)) {
					sb.append(" UNDEF ");
				} else {
					RDFNode rn = qs.get(var);
					if (rn.isResource()) {
						sb.append(" <" + rn.asResource() + "> ");
					} else {
						Literal l = rn.asLiteral();
						RDFDatatype rt = l.getDatatype();
						if (rt.getJavaClass().equals(String.class)) {
							sb.append("\"" + StringEscapeUtils.escapeJava(l.getString()) + "\" ");
						} else {
							sb.append(l.getValue() + " ");
						}
					}
				}
			}

			sb.append(") ");
		}

		sb.append("} ");

		qe.close();
		dataModel.close();

		return sb.toString();
	}
	
	public static String queryStringAsValues(String queryString, Model dataModel) {
		StringBuilder sb = new StringBuilder();
		sb.append("VALUES (");

		QueryExecution qe = QueryExecutionFactory.create(queryString, dataModel);
		ResultSet rs = qe.execSelect();

		List<String> vars = rs.getResultVars();
		for (String var : vars) {
			sb.append("?" + var + " ");
		}

		sb.append(") { ");

		while (rs.hasNext()) {
			QuerySolution qs = rs.next();
			sb.append("( ");

			for (String var: vars) {
				if (!qs.contains(var)) {
					sb.append(" UNDEF ");
				} else {
					RDFNode rn = qs.get(var);
					if (rn.isResource()) {
						sb.append(" <" + rn.asResource() + "> ");
					} else {
						Literal l = rn.asLiteral();
						RDFDatatype rt = l.getDatatype();
						if (rt.getJavaClass().equals(String.class)) {
							sb.append("\"" + StringEscapeUtils.escapeJava(l.getString()) + "\" ");
						} else {
							sb.append(l.getValue() + " ");
						}
					}
				}
			}

			sb.append(") ");
		}

		sb.append("} ");

		qe.close();

		return sb.toString();
	}
	
	public static String getVariableFixpoint(String fixpoint_string) {
		String result = fixpoint_string.trim();
		result = result.substring(8).trim();
		result = result.substring(1, result.length() - 1);
		result = result.trim();
		
		return result;
	}

	/* public static String generateValues(String queryString, Context context, String dataPath) {
		List<String> valuesVars = Utilities.varNamesValues(queryString);
		List<int[]> valuesPositions = Utilities.splitLocation(queryString);

		if (valuesVars.size() == 0) {
			return Utilities.queryStringAsValues(queryString, dataPath);
		} else {
			int substringIndex = 0;
			StringBuilder sb = new StringBuilder();
			for (int i = 0; i < valuesVars.size(); i++) {
				sb.append(queryString.substring(substringIndex, valuesPositions.get(i)[0]) + 
						generateValues(context.assignations.get(valuesVars.get(i)), context, dataPath));
				substringIndex = valuesPositions.get(i)[1];
			}
			sb.append(queryString.substring(substringIndex, queryString.length()));
			return sb.toString();
		}
	} */

}
