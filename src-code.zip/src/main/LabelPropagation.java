package main;

import java.util.List;

import org.apache.jena.rdf.model.Model;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.tdb.TDBLoader;

public class LabelPropagation {

	public static void main(String[] args) {
		
		Model dataModel = ModelFactory.createDefaultModel();
		dataModel.read(args[0]);
		
		AssignStatement node_label = new AssignStatement(
				"node_label", 
				"SELECT DISTINCT ?node ?label (?label AS ?labelPrev) WHERE { { ?node <http://example.org/l> ?label } }"
				);
		
		/* AssignStatement self_edges = new AssignStatement(
				"self_edges", 
				"SELECT DISTINCT ?node WHERE { { ?node ?p ?o } }"
				); */
		
		AssignStatement neighbour_label_count = new AssignStatement(
				"neighbour_label_count", 
				"SELECT ?node ?label (COUNT(?neighbour) AS ?count) WHERE { "
				+ "{ { ?node ?p ?neighbour } UNION { ?neighbour ?p ?node } UNION { ?node <http://example.org/zero>? ?neighbour } } . "
				+ "FILTER(!isLiteral(?node)) . "
				+ "{ SELECT (?node AS ?neighbour) ?label WHERE { QVALUES(node_label) } } } GROUP BY ?node ?label"
				);
		
		AssignStatement max_neighbour_label_count = new AssignStatement(
				"max_neighbour_label_count", 
				"SELECT ?node (MAX(?count) AS ?max) WHERE { { SELECT * WHERE { QVALUES(neighbour_label_count) } } } GROUP BY ?node"
				);
		
		AssignStatement node_label2 = new AssignStatement(
				"node_label", 
				"SELECT ?node (MIN(?lab) AS ?label) (?labelPrev2 AS ?labelPrev) WHERE { "
					+ "{ SELECT ?node (?label AS ?lab) ?count WHERE { QVALUES(neighbour_label_count) } } . "
					+ "{ SELECT * WHERE { QVALUES(max_neighbour_label_count) } } . FILTER(?count = ?max) "
					+ "OPTIONAL { { SELECT ?node (?label AS ?labelPrev2) WHERE { QVALUES(node_label) } } } "
				+ "} GROUP BY ?node ?labelPrev2"
				);
		
		
		Procedure p = new Procedure(dataModel);
		Procedure p2 = new Procedure(dataModel, p.context);
		
		
		OutputStatement out = new OutputStatement("node_label");
		// OutputStatement out2 = new OutputStatement("neighbour_label_count");
		// OutputStatement out3 = new OutputStatement("max_neighbour_label_count");
		
		p.statements.add(node_label);
		// p.statements.add(self_edges);
		
		p2.statements.add(neighbour_label_count);
		p2.statements.add(max_neighbour_label_count);
		p2.statements.add(node_label2);
		p2.statements.add(out);
		
		
		// String askString = "ASK { { SELECT * WHERE { QVALUES(node_label) . FILTER(!bound(?labelPrev) || ?labelPrev!=?label) } } }";
		
		LoopStatement lst = new LoopStatement(7, p2);
		
		
		
		p.statements.add(lst);
		p.statements.add(out);
		
		
		long start = System.currentTimeMillis();

		p.execProcedure();
		
		long total = System.currentTimeMillis() - start;
		
		System.out.println("END - Time: " + total);
		

				
	}

}
