package main;

import java.util.List;

import org.apache.jena.tdb.TDBLoader;

public class ExecProcedure {

	public static void main(String[] args) {
		
		AssignStatement st0 = new AssignStatement(
				"reachable", 
				"SELECT ?s ?line ?adj WHERE { " + 
				"  ?s <http://www.wikidata.org/prop/direct/P17> <http://www.wikidata.org/entity/Q414> . " + 
				"  ?s <http://www.wikidata.org/prop/direct/P31> <http://www.wikidata.org/entity/Q928830> . " + 
				"  ?s <http://www.wikidata.org/prop/direct/P81> ?line . " + 
				"  ?s <http://www.wikidata.org/prop/direct/P197> ?adj " + 
				"}"
				);
		
		AssignStatement st1 = new AssignStatement(
				"reachable", 
				"SELECT ?s WHERE { " + 
				"<http://www.wikidata.org/entity/Q3296629> <http://www.wikidata.org/prop/direct/P197> ?s . " + 
				"MINUS { ?s <http://www.wikidata.org/prop/direct/P81> <http://www.wikidata.org/entity/Q1157050> } }"
				);
		
		AssignStatement st2 = new AssignStatement(
				"adjacent_not_c", 
				"SELECT ?s WHERE { " + 
				"      ?prev_s <http://www.wikidata.org/prop/direct/P197> ?s . " + 
				"      MINUS { ?s <http://www.wikidata.org/prop/direct/P81> <http://www.wikidata.org/entity/Q1157050> } . " + 
				"      {  " + 
				"        SELECT (?s AS ?prev_s)  " + 
				"        WHERE {  " + 
				"          QVALUES(reachable)  " + 
				"        }  " + 
				"      } " + 
				"    }"
				);
		
		AssignStatement st3 = new AssignStatement(
				"reachable", 
				"SELECT DISTINCT ?s WHERE { " + 
				"      { QVALUES(adjacent_not_c) } " + 
				"      UNION " + 
				"      { QVALUES(reachable) } " + 
				"    }"
				);
		
		
		Procedure p = new Procedure("/Users/adriansotosuarez/Documents/Research/SPARQL-Analytics/ExamplesPaper/metro");
		Procedure p2 = new Procedure("/Users/adriansotosuarez/Documents/Research/SPARQL-Analytics/ExamplesPaper/metro", p.context);
		
		
		
		p.statements.add(st1);
		p2.statements.add(st2);
		p2.statements.add(st3);
		
		// String askString = "ASK { QVALUES(b) } ";
		String fixpointString = "FIXPOINT(reachable)";
		
		LoopStatement lst = new LoopStatement(fixpointString, p2);
		
		OutputStatement st4 = new OutputStatement("reachable");
		
		p.statements.add(lst);
		p.statements.add(st4);
		
		long start = System.currentTimeMillis();

		p.execProcedure();

		long total = System.currentTimeMillis() - start;

		System.out.println("END - Time: " + total);

				
	}

}
