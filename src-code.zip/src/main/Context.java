package main;

import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.jena.datatypes.RDFDatatype;
import org.apache.jena.query.Dataset;
import org.apache.jena.query.QueryExecution;
import org.apache.jena.query.QueryExecutionFactory;
import org.apache.jena.query.QuerySolution;
import org.apache.jena.query.ResultSet;
import org.apache.jena.query.ResultSetFormatter;
import org.apache.jena.rdf.model.Literal;
import org.apache.jena.rdf.model.Model;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.rdf.model.RDFNode;
import org.apache.jena.tdb.TDBFactory;
import org.apache.jena.update.UpdateAction;

public class Context {

	public HashMap<String, String> assignations;
	public String dataPath;
	public Model dataModel;

	public Context(String dataPath) {

		this.assignations = new HashMap<String, String>();
		this.dataPath = dataPath;

	}

	public Context(Model dataModel) {

		this.assignations = new HashMap<String, String>();
		this.dataModel = dataModel;

	}

	public void printResultSet(String varName) {

		String queryString = this.assignations.get(varName);

		if (this.dataModel == null) {
			Dataset dataset = TDBFactory.createDataset(this.dataPath);
			this.dataModel = dataset.getDefaultModel();
		}


		QueryExecution qe = QueryExecutionFactory.create(queryString, dataModel);
		ResultSet rs = qe.execSelect();

		if (Utilities.PRINT_VALUES) {
			String queryResult = ResultSetFormatter.asText(rs);
			System.out.println(queryResult);
		} else {
			int count = 0;
			while (rs.hasNext()) {
				rs.next();
				count++;
			}
			System.out.println("Mappings: " + count);
		}
		

		if (this.dataModel == null) {
			dataModel.close();
		}
		// dataModel.close();

	}

	public String generateValues(String varName) {
		String queryString = this.assignations.get(varName);
		List<String> valuesVars = Utilities.varNamesValues(queryString);
		List<int[]> valuesPositions = Utilities.splitLocation(queryString);

		if (valuesVars.size() == 0) {
			if (this.dataModel == null) {
				return Utilities.queryStringAsValues(queryString, this.dataPath);
			} else {
				return Utilities.queryStringAsValues(queryString, this.dataModel);
			}
		} else {
			int substringIndex = 0;
			StringBuilder sb = new StringBuilder();
			for (int i = 0; i < valuesVars.size(); i++) {
				sb.append(queryString.substring(substringIndex, valuesPositions.get(i)[0]) + 
						generateValues(valuesVars.get(i)));
				substringIndex = valuesPositions.get(i)[1];
			}
			sb.append(queryString.substring(substringIndex, queryString.length()));
			return sb.toString();
		}
	}


	public void setQueryString(String varName, String queryString) {

		this.assignations.put(varName, getQueryString(queryString));	

	}
	
	public String getQueryStringByVar(String varName) {
		return this.assignations.get(varName);
	}

	public String getQueryString(String queryString) {
		List<String> valuesVars = Utilities.varNamesValues(queryString);
		List<int[]> valuesPositions = Utilities.splitLocation(queryString);

		if (valuesVars.size() > 0) {

			int substringIndex = 0;
			StringBuilder sb = new StringBuilder();
			for (int i = 0; i < valuesVars.size(); i++) {
				sb.append(queryString.substring(substringIndex, valuesPositions.get(i)[0]) + 
						generateValues(valuesVars.get(i)));
				substringIndex = valuesPositions.get(i)[1];
			}
			sb.append(queryString.substring(substringIndex, queryString.length()));
			return sb.toString();

		} else {

			return queryString;

		}	
	}

	// Not sure if this works
	/*
	public void execUpdate(String queryString) {

		Dataset dataset = TDBFactory.createDataset(tdbPath);
		Model tdb = dataset.getDefaultModel();

		List<String> valuesVars = Utilities.varNamesValues(queryString);
		List<int[]> valuesPositions = Utilities.splitLocation(queryString);

		if (valuesVars.size() > 0) {
			int substringIndex = 0;
			StringBuilder sb = new StringBuilder();
			for (int i = 0; i < valuesVars.size(); i++) {
				sb.append(queryString.substring(substringIndex, valuesPositions.get(i)[0])); 
				sb.append(generateValues(valuesVars.get(i)));
				substringIndex = valuesPositions.get(i)[1];
			}
			sb.append(queryString.substring(substringIndex, queryString.length()));
			UpdateAction.parseExecute(sb.toString(), tdb);

		} else {

			UpdateAction.parseExecute(queryString, tdb);

		}

		tdb.close();

	}
	 */

}
