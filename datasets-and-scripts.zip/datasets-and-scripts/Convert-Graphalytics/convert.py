DIRECTED = True
LABELS = False
FILENAME = 'data-graphalytics'
PREFIX = 'http://example.org/'

f = open('small_edges.txt', 'r')
f2 = open('{}.nt'.format(FILENAME), 'w', encoding='UTF-8')

l = f.readline()
s = set()
while l:
    values = l.split()
    f2.write(
        '<{}v{}> <{}p> <{}v{}> . \n'.format(PREFIX, values[0], PREFIX, PREFIX, values[1])
    )
    if not DIRECTED:
        f2.write(
            '<{}v{}> <{}p> <{}v{}> . \n'.format(PREFIX, values[1], PREFIX, PREFIX, values[0])
        )
    l = f.readline()
    if LABELS:
        s.add(values[0])
        s.add(values[1])

if LABELS:
    for label in s:
        f2.write(
            '<{}v{}> <{}l> "{}" . \n'.format(PREFIX, label, PREFIX, label)
        )

f.close()
f2.close()